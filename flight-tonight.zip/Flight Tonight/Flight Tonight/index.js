// script.js
// Passenger Module
const passengerForm = document.getElementById('passenger-module');
passengerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const surname = document.getElementById('surname').value;
    const name = document.getElementById('name').value;
    const address = document.getElementById('address').value;
    const phone = document.getElementById('phone').value;
    console.log(`Passenger: ${surname} ${name}, ${address}, ${phone}`);
});

// Flight Module
const flightForm = document.getElementById('flight-module');
flightForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const flightnum = document.getElementById('flightnum').value;
    const origin = document.getElementById('origin').value;
    const dest = document.getElementById('dest').value;
    const date = document.getElementById('date').value;
    const arrTime = document.getElementById('arr-time').value;
    const depTime = document.getElementById('dep-time').value;
    console.log(`Flight: ${flightnum}, ${origin} to ${dest}, ${date}, Arrival: ${arrTime}, Departure: ${depTime}`);
});

// Staff Module
const staffForm = document.getElementById('staff-module');
staffForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const empnum = document.getElementById('empnum').value;
    const surname = document.getElementById('surname').value;
    const name = document.getElementById('name').value;
    const address = document.getElementById('address').value;
    const phone = document.getElementById('phone').value;
    const salary = document.getElementById('salary').value;
    console.log(`Staff: ${empnum}, ${surname} ${name}, ${address}, ${phone}, Salary: ${salary}`);
});

// Airplane Module
const airplaneForm = document.getElementById('airplane-module');
airplaneForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const sernum = document.getElementById('sernum').value;
    const manufacturer = document.getElementById('manufacturer').value;
    const model = document.getElementById('model').value;
    console.log(`Airplane: ${sernum}, ${manufacturer}, ${model}`);
});

// City Module
const cityForm = document.getElementById('city-module');
cityForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const city = document.getElementById('city').value;
    console.log(`City: ${city}`);
});